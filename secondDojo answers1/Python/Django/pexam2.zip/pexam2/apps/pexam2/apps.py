from django.apps import AppConfig


class Pexam2Config(AppConfig):
    name = 'pexam2'

from django.apps import AppConfig


class PexamConfig(AppConfig):
    name = 'pexam'

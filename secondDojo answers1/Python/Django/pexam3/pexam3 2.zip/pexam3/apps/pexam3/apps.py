from django.apps import AppConfig


class Pexam3Config(AppConfig):
    name = 'pexam3'

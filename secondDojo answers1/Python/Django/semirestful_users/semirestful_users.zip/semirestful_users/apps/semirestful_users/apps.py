from django.apps import AppConfig

class SemirestfulUsersConfig(AppConfig):
    name = 'semirestful_users'

from django.apps import AppConfig


class LoginregConfig(AppConfig):
    name = 'loginreg'

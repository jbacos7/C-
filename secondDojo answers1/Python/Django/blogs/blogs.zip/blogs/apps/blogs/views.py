# Create your views here.
from __future__ import unicode_literals
from django.shortcuts import render, HttpResponse, redirect

def index(request):
    response = "This is the index route."
    return HttpResponse(response)
def new(request):
    response = "This is new new new new new."
    return HttpResponse (response)
def create(request):
    response = "This is create create create create."
    return HttpResponse(response)
def show(request, num):
    response = "this is a placeholder for show blog blog  " + num
    return HttpResponse(response)
def edit(request, num):
    response = "this is a placeholder for edit blog blog " + num
    return HttpResponse(response)


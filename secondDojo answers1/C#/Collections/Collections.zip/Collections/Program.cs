﻿using System;
using System.Collections.Generic;

namespace Collections
{
    class Program
    {
        static void Main(string[] args)
        {    
        // Create an array to hold integer values 0 through 9
        // List<int> nums = new List<int>();
        //     for(int i = 0; i< 10; i++)
        //     {
        //         nums.Add(i);
        //         Console.WriteLine(nums[i]);
        //     }   

        // Create an array of the names "Tim", "Martin", "Nikki", & "Sara"
        // List<string> names = new List<string>();
        // {
        //     names.Add("Tim");
        //     names.Add("Martin");
        //     names.Add("Nikki");
        //     names.Add("Sara");
        //     Console.WriteLine(names[0] + "," + names[1] + "," + names[2]+ "," + names[3]);
        // }

        // Create an array of length 10 that alternates between true and false values, starting with true.

        // Create a list of ice cream flavors that holds at least 5 different flavors (feel free to add more than 5!)
        // List<string> ice = new List<string>();
        // {
        //     ice.Add("Chocolate");
        //     ice.Add("Vanilla");
        //     ice.Add("Cinnamon");
        //     ice.Add("Rocky Road");
        //     ice.Add("Oreo");
        //     Console.WriteLine(ice[0] + "," + ice[1] + "," + ice[2]+ "," + ice[3]+ "," + ice[4]);
        // }


        // Output the length of this list after building it
        // List<string> ice = new List<string>();
        // {
        //     ice.Add("Chocolate");
        //     ice.Add("Vanilla");
        //     ice.Add("Cinnamon");
        //     ice.Add("Rocky Road");
        //     ice.Add("Oreo");
        //     Console.WriteLine(ice[0] + "," + ice[1] + "," + ice[2]+ "," + ice[3]+ "," + ice[4]);
        //     Console.WriteLine(ice.Count);
        // }

        // Output the third flavor in the list, then remove this value
        // Output the new length of the list (It should just be one fewer!)
        // List<string> ice = new List<string>();
        // {
        //     ice.Add("Chocolate");
        //     ice.Add("Vanilla");
        //     ice.Add("Cinnamon");
        //     ice.Add("Rocky Road");
        //     ice.Add("Oreo");
        //     Console.WriteLine(ice[2]);
        //     ice.RemoveAt(2);
        //     Console.WriteLine(ice.Count);
        // }

        // Create a dictionary that will store both string keys as well as string values


        Dictionary<string,string> profile = new Dictionary<string,string>();
        //Almost all the methods that exists with Lists are the same with Dictionaries
        {
        profile.Add("Name", "Amanda");
        profile.Add("Name", "Evan");
        profile.Add("Name", "Natalie");
        profile.Add("Name", "Ty");
        profile.Add("Ice Cream", "Chocolate");
        profile.Add("Ice", "Rocky Road");
        profile.Add("Ice", "Vanilla");
        profile.Add("Ice", "Oreo");

        // foreach (var entry in profile)


        foreach (KeyValuePair<string,string> entry in profile)
        {
        Console.WriteLine(entry.Key + " - " + entry.Value);
        }

        // {
        // Console.WriteLine("Favorite Ice Cream");
        // Console.WriteLine(entry.Key + " - " + entry.Value);
        // }
        // Console.WriteLine("Favorite Ice Cream");
        // Console.WriteLine("Name - " + profile["Name"]);
        // Console.WriteLine("Ice Cream - " + profile["Ice"]);
        // Console.WriteLine("Favorite Ice Cream - " + profile["Ice"]);
        }
        }
    }
}







    //     string nums= "";
    //     for (int i = 0; i< 10; i++){
    //         nums += i + ',';
    //     }
    //     var arr= nums.Split(new []{','});
    //     Console.WriteLine()
    // }   
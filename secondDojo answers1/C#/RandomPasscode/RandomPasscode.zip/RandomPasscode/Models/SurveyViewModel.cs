using System.ComponentModel.DataAnnotations;
namespace RandomPasscode.Models

{
    public class SurveyViewModel
    {

///////////////////////////////////////////////

        
    }
}
using System;
using System.Collections.Generic;


namespace ViewModelFun.Models
{
    public class User
    {
        public string thisuser { get; set; }

    }
}
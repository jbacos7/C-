using System;
using System.Collections.Generic;

namespace ViewModelFun.Models
{
    public class Index
    {
        public string message { get; set; }

    }
}
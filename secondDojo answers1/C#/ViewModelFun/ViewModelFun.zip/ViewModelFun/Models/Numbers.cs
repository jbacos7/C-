using System;
using System.Collections.Generic;


namespace ViewModelFun.Models
{
    public class Numbers
    {
        public int[] nums { get; set;}

    }
}
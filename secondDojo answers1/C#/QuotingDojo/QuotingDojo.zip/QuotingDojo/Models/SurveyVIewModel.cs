using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
using System.ComponentModel.DataAnnotations;
namespace QuotingDojo.Models


{
    public class SurveyViewModel
    {

///////////////////////////////////////////////

        
    }
}